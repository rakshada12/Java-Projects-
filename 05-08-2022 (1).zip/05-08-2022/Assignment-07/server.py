import socket

s = socket.socket()
print ("Socket successfully created")

port = 40675

s.bind(('', port))
print ("socket binded to %s" %(port))

s.listen(5)	
print ("socket is listening")

file = open("test.txt",'rb')
file_data=file.read(1024)
print (file_data)

while True:

	c, addr = s.accept()
	print ('Got connection from', addr )

	c.send(file_data)

	c.close()