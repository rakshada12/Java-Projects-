import socket

s = socket.socket()

port = 40675

s.connect(('127.0.0.1', port))
file=open("newtest.txt",'wb')
file.write(s.recv(1024))
print("File saved successfully!")
s.close()