# Food App

This project is desined to practice debugging skills and implement what you have learned in the previous sessions. 

## Learning Points
- Understanding the project flow.
- Understanding the component connection.

## How to get this project up and running in your machine.
-	Create a project: name it as food app (npx create-react-app food-app)
-	Delete your application src folder, Copy the src folder of this app and paste in your app.
-	run and test your app using (npm start) command

## Scope
- Treat this project as the starting point.
- We have concepts like, Reducer, Context API and many more that we want to implment on this app. 
- Just to save time, this much of code is provided, try to understand this code. 

