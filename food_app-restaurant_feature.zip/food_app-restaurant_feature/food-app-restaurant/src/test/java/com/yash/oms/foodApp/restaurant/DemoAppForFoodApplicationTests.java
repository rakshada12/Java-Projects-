package com.yash.oms.foodApp.restaurant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoAppForFoodApplicationTests {

	@Test
	void contextLoads() {
	}

}
