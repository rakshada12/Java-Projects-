package com.yash.oms.foodApp.restaurant.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.UUID;

@Entity
@Data
public class Restaurant {
    @Id
    @GeneratedValue
    private UUID restaurantId;
    private String restaurantName;
    private String contactNumber;
    private String address;
    @OneToMany(mappedBy = "restaurant",cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<Item> itemList;

}
