package com.yash.oms.foodApp.restaurant.service;

import com.yash.oms.foodApp.restaurant.dto.ItemDTO;
import com.yash.oms.foodApp.restaurant.dto.RestaurantWithItemsDTO;
import com.yash.oms.foodApp.restaurant.entity.Item;
import com.yash.oms.foodApp.restaurant.entity.Restaurant;
import com.yash.oms.foodApp.restaurant.repository.ItemRepository;
import com.yash.oms.foodApp.restaurant.repository.RestaurantRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class RestaurantService {
    @Autowired
    private RestaurantRepository restaurantRepository;
    @Autowired
    private ItemRepository itemRepository;
    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private ItemServiceCall itemService;

    public Restaurant addRestaurant(Restaurant restaurant) {
        System.out.println("In Service");
        Restaurant save = restaurantRepository.save(restaurant);
        System.out.println(save);
        return save;
    }

    public Restaurant updateRestaurant(UUID id, Restaurant restaurant) {
        if (!restaurantRepository.existsById(id)) {
        }
        restaurant.setRestaurantId(id);
        return restaurantRepository.save(restaurant);
    }

    public void removeRestaurant(UUID restaurantId) {
        if (!restaurantRepository.existsById(restaurantId)) {

        }
        restaurantRepository.deleteById(restaurantId);
    }

    public Restaurant viewRestaurant(UUID restaurantId) {
        return restaurantRepository.findById(restaurantId).orElse(null);
    }

    public List viewAllRestaurants() {
        return restaurantRepository.findAll();
    }

    @Transactional
    public RestaurantWithItemsDTO addItemToRestaurant(UUID restaurantId) {
        Restaurant restaurant = viewRestaurant(restaurantId);
        ResponseEntity<List<Item>> itemDetails = itemService.getItemDetails();
        List<Item> itemList = itemDetails.getBody();
        RestaurantWithItemsDTO response = new RestaurantWithItemsDTO();
        if (restaurant != null && itemList != null) {
            response.setRestaurantId(restaurant.getRestaurantId());
            response.setRestaurantName(restaurant.getRestaurantName());
            response.setContactNumber(restaurant.getContactNumber());
            response.setAddress(restaurant.getAddress());
            List<ItemDTO> items = new ArrayList<>();
            List<Item> validItems = new ArrayList<>();//

            Set<String> existingItemNames = restaurant.getItemList().stream().map(Item::getItemName).collect(Collectors.toSet());
            for (Item item : itemList) {
                Item existingItem = itemService.getItemByName(item.getItemName());
                if (existingItem != null) {
                    if (!existingItemNames.contains(existingItem.getItemName())) {
                        existingItem.setRestaurant(restaurant); //
                        validItems.add(existingItem);//
                        existingItemNames.add(existingItem.getItemName());
                        ItemDTO itemDTO = new ItemDTO();
                        itemDTO.setItemId(existingItem.getItemId());
                        itemDTO.setItemName(existingItem.getItemName());
                        itemDTO.setQuantity(existingItem.getQuantity());
                        itemDTO.setCost(existingItem.getCost());
                        items.add(itemDTO);
                    } else {
                        ItemDTO itemDTO = new ItemDTO();
                        itemDTO.setItemId(existingItem.getItemId());
                        itemDTO.setItemName(existingItem.getItemName());
                        itemDTO.setQuantity(existingItem.getQuantity());
                        itemDTO.setCost(existingItem.getCost());
                        items.add(itemDTO);
                    }
                } else {
                    Item newItem = new Item();
                    newItem.setItemName(item.getItemName());
                    newItem.setQuantity(item.getQuantity());
                    newItem.setCost(item.getCost());
                    newItem.setRestaurant(restaurant);
                    newItem = itemRepository.save(newItem);
                    validItems.add(newItem);

                    ItemDTO itemDTO = new ItemDTO();
                    itemDTO.setItemId(newItem.getItemId());
                    itemDTO.setItemName(newItem.getItemName());
                    itemDTO.setQuantity(newItem.getQuantity());
                    itemDTO.setCost(newItem.getCost());
                    items.add(itemDTO);

                }
            }
            response.setItems(items);
            restaurant.setItemList(validItems);
            restaurantRepository.save(restaurant);
        }
        return response;
    }
}
