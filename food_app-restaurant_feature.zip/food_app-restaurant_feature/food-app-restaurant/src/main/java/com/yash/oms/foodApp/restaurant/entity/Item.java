package com.yash.oms.foodApp.restaurant.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.UUID;

@Entity
@Data
public class Item {
    @Id
    @GeneratedValue
    private UUID itemId;
    private String itemName;
    private int quantity;
    private double cost;
    @ManyToOne
    @JoinColumn(name = "restaurant_id",nullable = false)
    @JsonBackReference
    private Restaurant restaurant;
}
