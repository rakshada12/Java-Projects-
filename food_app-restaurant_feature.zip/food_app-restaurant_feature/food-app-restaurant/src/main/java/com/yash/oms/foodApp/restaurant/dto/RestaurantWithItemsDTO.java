package com.yash.oms.foodApp.restaurant.dto;

import lombok.Data;

import java.util.List;
import java.util.UUID;
@Data
public class RestaurantWithItemsDTO {
    private UUID restaurantId;
    private String restaurantName;
    private String contactNumber;
    private String address;
    private List<ItemDTO> items;
}
