package com.yash.oms.foodApp.restaurant.service;

import com.yash.oms.foodApp.restaurant.entity.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.UUID;

@Service
public class ItemServiceCall {
    @Autowired
    private RestTemplate restTemplate;

    public ResponseEntity<List<Item>> getItemDetails() {
        ResponseEntity<List<Item>> forObject = restTemplate.exchange("http://localhost:9091/items", HttpMethod.GET, null, new ParameterizedTypeReference<List<Item>>() {
        });
        List<Item> body = forObject.getBody();
        System.out.println("Item Data " + body);
        return forObject;
    }
    public Item getItemById(UUID id) {
        String url = String.format("http://localhost:9091/items/%s", id);
        Item forObject = restTemplate.getForObject(url, Item.class);
        return forObject;
    }

    public Item getItemByName(String name) {
        String url = String.format("http://localhost:9091/items/name/%s",name);
        Item forObject = restTemplate.getForObject(url, Item.class);
        return forObject;
    }
}
