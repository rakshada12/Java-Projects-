package com.yash.oms.foodApp.restaurant.controller;
import com.yash.oms.foodApp.restaurant.dto.RestaurantWithItemsDTO;
import com.yash.oms.foodApp.restaurant.entity.Restaurant;
import com.yash.oms.foodApp.restaurant.service.RestaurantService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/restaurants")
public class RestaurantController {
    @Autowired
    private RestaurantService restaurantService;

    private static final Logger logger = LoggerFactory.getLogger(RestaurantController.class);

    @PostMapping
    public Restaurant addRestaurant(@RequestBody Restaurant restaurant) {
       logger.info("Adding restaurant call to restaurant service");
        return restaurantService.addRestaurant(restaurant);
    }

    @PutMapping("/{id}")
    public Restaurant updateRestaurant(@PathVariable UUID id, @RequestBody Restaurant restaurant) {
        logger.info("Update restaurant call to restaurant service");
        return restaurantService.updateRestaurant(id, restaurant);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> removeRestaurant(@PathVariable UUID id) {
        restaurantService.removeRestaurant(id);
        logger.info("Delete restaurant call to restaurant service");
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}")
    public Restaurant viewRestaurant(@PathVariable UUID id) {
        logger.info("Get restaurant by ID call to restaurant service");
        return restaurantService.viewRestaurant(id);
    }

    @GetMapping
    public List<Restaurant> viewAllRestaurants() {
        return restaurantService.viewAllRestaurants();
    }

    @PostMapping("/{id}/items")
    public RestaurantWithItemsDTO addItemsToRestaurant(@PathVariable UUID id) {
        logger.info("Adding Items in restaurant call to restaurant service");
        return restaurantService.addItemToRestaurant(id);
    }


}
