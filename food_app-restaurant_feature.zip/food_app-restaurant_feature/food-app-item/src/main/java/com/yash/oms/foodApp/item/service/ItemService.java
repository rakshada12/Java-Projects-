package com.yash.oms.foodApp.item.service;

import com.yash.oms.foodApp.item.entity.Item;
import com.yash.oms.foodApp.item.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class ItemService {
    @Autowired
    private ItemRepository itemRepository;

    public Item addItem(Item item) {
        return itemRepository.save(item);
    }

    public Item updateItem(Item item) {
        return itemRepository.save(item);
    }

    public void removeItem(UUID itemId) {
        itemRepository.deleteById(itemId);
    }

    public Item viewItem(UUID itemId) {
        return itemRepository.findById(itemId).orElse(null);
    }

    public List<Item> viewAllItems() {
        List<Item> all = itemRepository.findAll();
        return all;
    }
    public Item getItemByName(String itemName){
        return itemRepository.findByItemName(itemName);
    }
}
