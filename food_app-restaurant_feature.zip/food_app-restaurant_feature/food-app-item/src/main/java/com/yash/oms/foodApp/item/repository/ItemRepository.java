package com.yash.oms.foodApp.item.repository;

import com.yash.oms.foodApp.item.entity.Item;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;
@Repository
public interface ItemRepository extends JpaRepository<Item, UUID> {
    Item findByItemName(String itemName);
}
