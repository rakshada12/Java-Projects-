package com.yash.oms.foodApp.item.controller;

import com.yash.oms.foodApp.item.entity.Item;
import com.yash.oms.foodApp.item.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/items")
public class ItemController {
    @Autowired
    private ItemService itemService;

    @PostMapping
    public Item addItem(@RequestBody Item item) {
        return itemService.addItem(item);
    }


    @GetMapping("/name/{itemName}")
    public ResponseEntity<Item> getItemByName(@PathVariable String itemName){
        Item item = itemService.getItemByName(itemName);
        return item !=null ?ResponseEntity.ok(item):ResponseEntity.notFound().build();
    }
    @PutMapping
    public Item updateItem(@RequestBody Item item) {
        return itemService.updateItem(item);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> removeItem(@PathVariable UUID id) {
        itemService.removeItem(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}")
    public Item viewItem(@PathVariable UUID id) {
        return itemService.viewItem(id);
    }

    @GetMapping
    public List<Item> viewAllItems() {
        return itemService.viewAllItems();
    }
}
