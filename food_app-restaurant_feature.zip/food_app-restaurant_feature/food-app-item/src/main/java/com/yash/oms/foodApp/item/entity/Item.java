package com.yash.oms.foodApp.item.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.Data;

import java.util.UUID;
@Entity
@Data
public class Item {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private UUID itemId;
    @JsonProperty("itemName")
    private String itemName;
    @JsonProperty("quantity")
    private int quantity;
    @JsonProperty("cost")
    private double cost;
}
