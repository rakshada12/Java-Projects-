package com.yash.euserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EuserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
