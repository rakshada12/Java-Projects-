package com.yash.technology.hotel.booking.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yash.technology.hotel.booking.entity.TempBooking;

@Repository
public interface TempBookingRepository extends JpaRepository<TempBooking, String>{

}
