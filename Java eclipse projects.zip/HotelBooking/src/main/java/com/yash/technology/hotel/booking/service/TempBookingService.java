package com.yash.technology.hotel.booking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.technology.hotel.booking.entity.TempBooking;
import com.yash.technology.hotel.booking.repository.TempBookingRepository;

@Service
public class TempBookingService {

	@Autowired
	private TempBookingRepository repository;
	
	public int doBooking(TempBooking booking)
	{
		TempBooking b=this.repository.save(booking);
		System.out.println(b.getBookingId());
		return 0;
	}
	public boolean isExists(String id)
	{
	 return (this.repository.existsById(id));
	}

		public TempBooking getTempBooking(String id)
		{
			try
			{
				System.out.print("id :" +id);
			TempBooking tb= this.repository.findById(id).get();
			System.out.println(tb);
			return tb;
			}catch(Exception e)
			{
				System.out.println(e);
				return null;
			}
		}
	
		
}
