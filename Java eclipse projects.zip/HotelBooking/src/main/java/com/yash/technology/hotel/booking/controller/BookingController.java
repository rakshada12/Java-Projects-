package com.yash.technology.hotel.booking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.yash.technology.hotel.booking.entity.Booking;
import com.yash.technology.hotel.booking.entity.TempBooking;
import com.yash.technology.hotel.booking.service.BookingSerivce;
import com.yash.technology.hotel.booking.service.TempBookingService;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;


@CrossOrigin(origins="http://localhost:3000")
@RestController
public class BookingController {
	
	private static final Logger logger = LoggerFactory.getLogger(BookingController.class);
	 
	
	@Autowired
	private BookingSerivce service;
	
	@Autowired
	private TempBookingService tempService;
	
	@PostMapping("/saveBooking")
	public String saveBooking(@RequestBody List<String> lst)
	{
		logger.info("Booking data save in temporary table code starts here");
		TempBooking tb=null;
		System.out.print(lst);
		Booking b=new Booking();
		for(int i=0;i<lst.size();i++)
		{
		tb=this.tempService.getTempBooking(lst.get(i));
		if(tb==null)
		{
			logger.error("Id coming from client are not present so error occur");
			return "Some problem occur";
		}
		b.setBookingId(tb.getBookingId());
		b.setContactNumber(tb.getContactNumber());
		b.setEmail(tb.getEmail());
		b.setEndDate(tb.getEndDate());
		b.setFirstName(tb.getFirstName());
		b.setGender(tb.getGender());
		b.setHotelRegistrationNumber(tb.getHotelRegistrationNumber());
		b.setLastName(tb.getLastName());
		b.setStartDate(tb.getStartDate());
		b.setTotal(b.getTotal());
		this.service.save(b);
		}
		logger.info("Data permanently saved after payment done by user");
		return "Data saved";
	}
	//here all the booking return for particular hotel registration number
	@GetMapping("/getBookings/{num}")
	public List<Booking> getBookings(@PathVariable ("num") String num)
	{
		List<Booking> b=this.service.getAllBookings(num);
		return b;
	}
	
}
