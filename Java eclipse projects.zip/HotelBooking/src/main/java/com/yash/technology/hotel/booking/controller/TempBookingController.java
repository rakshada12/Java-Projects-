package com.yash.technology.hotel.booking.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.yash.technology.hotel.booking.entity.HotelInformation;
import com.yash.technology.hotel.booking.entity.TempBooking;
import com.yash.technology.hotel.booking.entity.UserRegistration;
import com.yash.technology.hotel.booking.service.TempBookingService;
import com.yash.technology.hotel.booking.service.HotelInformationImpl;
import com.yash.technology.hotel.booking.service.UserRegistrationService;

@CrossOrigin(origins="http://localhost:3000")
@RestController
public class TempBookingController {

	@Autowired
	private TempBookingService service;
	
	@Autowired
	private HotelInformationImpl hotelService;
	
	public static String createId(String name,String number,String gender,String lastName)
	{
		char c1[]=name.toCharArray();
		char c2[]=number.toCharArray();
		char c3[]=lastName.toCharArray();
		String id="";
		        for(int i=0;i<3;i++)
				id+=Character.toString(c1[i]);
		        id+=gender;
		        for(int i=0;i<3;i++)
		        	id+=Character.toString(c2[i]);
		        for(int i=0;i<3;i++)
		        	id+=Character.toString(c3[i]);
		        Random r=new Random();
		        int x=r.nextInt(99);
		        id+=String.valueOf(x);
		return id;
	}
	 
	public static long calculateDays(Date startDate,Date endDate)
	{
		 long dateBeforeInMs=endDate.getTime();
		 long dateBeforeInMs1=startDate.getTime();
		 long timeDiff=Math.abs(dateBeforeInMs-dateBeforeInMs1);
		 long daysDiff=TimeUnit.DAYS.convert(timeDiff,TimeUnit.MILLISECONDS);	
		 return daysDiff;
	}
	private UserRegistrationService s;
	@PostMapping("/booking")
	public String hotelBooking(@RequestBody TempBooking booking)
	{
		long days=calculateDays(booking.getStartDate(),booking.getEndDate());
		String id=createId(booking.getFirstName(),booking.getContactNumber(), booking.getGender(), booking.getLastName());
		booking.setBookingId(id);
		//Set total charges
		HotelInformation h=this.hotelService.getInformation(booking.getHotelRegistrationNumber());
		booking.setTotal(days*(long)h.getCharges());
		
		//add data in temp database
		this.service.doBooking(booking);
		return String.valueOf(booking.getTotal());
	}
}
/*
 * Date dateBefore = new Date(2022, Calendar.APRIL, 21);
Date dateAfter = new Date(2022, Calendar.APRIL, 25);

long dateBeforeInMs = dateBefore.getTime();
long dateAfterInMs = dateAfter.getTime();

long timeDiff = Math.abs(dateAfterInMs - dateBeforeInMs);

long daysDiff = TimeUnit.DAYS.convert(timeDiff, TimeUnit.MILLISECONDS);
 * */
 