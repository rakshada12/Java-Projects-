package com.springmvc.orm.controller;

import java.io.PrintWriter;
import java.util.List;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springmvc.orm.controller.entity.Employee;
import com.springmvc.orm.controller.service.userService;



@Controller
public class MainController {
	
	
	
		@Autowired
		private userService userService;
	
		@RequestMapping("/")
		public String home()
		{
			return "home";
		}
	
		
		@RequestMapping("/login")
		public String login()
		{
			return "login";
		}
		
		@RequestMapping("/loginForm")
		public String loginForm(@ModelAttribute("emp") Employee emp,Model model)
		{
			
			
			int num = this.userService.createUser(emp);
			model.addAttribute("num", num);
			return "showData";
		}
		@RequestMapping("/delete")
		public String delete()
		{
			
			return "delete";
		}
		
		@RequestMapping("/deleteUser")
		public String deleteUser(@RequestParam("id") int id,Model model)
		{
		
			try {
			userService.deleteUsers(id);
			}
			catch (Exception e) {
				e.printStackTrace();
				model.addAttribute("delete" , "eneter valid id");
				return "showData";
			}
			model.addAttribute("delete" , "user deleted");
			return "showData";
		}
		
		@RequestMapping("retrive")
		public String retrive(Model model)
		{
			
			List<Employee> emp = this.userService.retriveAll();
			model.addAttribute("list",emp);
			return "retriveAll";
		}
		

}
