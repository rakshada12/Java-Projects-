package com.yash.atmsimulation.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter 
@Setter
@Entity
@Table
public class Account {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@NotNull(message="Account number cannot be null")
	private String accountNumber;
	@NotBlank(message="Please enter the account pin number")
	private String accountPin;
	private double balance;
	public Account(@NotNull(message = "Account number cannot be null") String accountNumber,
			@NotBlank(message = "Please enter the account pin number") String accountPin, double balance) {
		super();
		this.accountNumber = accountNumber;
		this.accountPin = accountPin;
		this.balance = balance;
	}
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
