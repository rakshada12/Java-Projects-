package com.yash.atmsimulation.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestParam;

import com.yash.atmsimulation.exceptions.AccountNotFoundException;
import com.yash.atmsimulation.exceptions.InsufficientFunds;
import com.yash.atmsimulation.exceptions.InvalidCredentialsException;
import com.yash.atmsimulation.model.Account;
import com.yash.atmsimulation.service.AccountService;
import com.yash.atmsimulation.serviceImpl.MapValidationErrorService;


import jakarta.validation.Valid;



@Controller
public class AccountController {
	@Autowired
	private AccountService accountService;
	@Autowired
	private MapValidationErrorService mapValidationErrorService;

	@GetMapping("/login")	
	public String showLoginPage() {
		return "login";
	}
	
	 @PostMapping("/login")
	    public String login(@RequestParam String accountNumber,
	                        @RequestParam String accountPin,
	                        Model model) {
	        try {
	            Account account = accountService.login(accountNumber, accountPin);
	            model.addAttribute("account", account);
	            return "dashboard";  
	        } catch (InvalidCredentialsException e) {
	            model.addAttribute("Wrong credentials", e.getMessage());
	            return "login";  
	        }
	 }
	 
	 @GetMapping("/balance")
	    public String checkBalance(@RequestParam Long accountId, Model model) {
	        double balance = accountService.checkBalance(accountId);
	        model.addAttribute("balance", balance);
	        return "balance";  
	    }
	 
	 @PostMapping("/withdraw")
	    public String withdraw(@RequestParam Long accountId,
	                           @RequestParam double amount,
	                           Model model) {
	        try {
	            accountService.withdraw(accountId, amount);
	            model.addAttribute("successMessage", "Withdrawal successful");
	        } catch (InsufficientFunds e) {
	            model.addAttribute("Funds are insufficient", e.getMessage());
	        }
	        return "dashboard";  
	    }
	 
	 @PostMapping("/deposit")
	    public String deposit(@RequestParam Long accountId,
	                          @RequestParam double amount,
	                          Model model) {
	        accountService.deposit(accountId, amount);
	        model.addAttribute("successMessage", "Deposit successful");
	        return "dashboard";  
	    }
	 
	    
	    @PostMapping("/transfer")
	    public String transfer(@RequestParam Long fromAccountId,
	                           @RequestParam Long toAccountId,
	                           @RequestParam double amount,
	                           Model model) {
	        try {
	            accountService.transfer(fromAccountId, toAccountId, amount);
	            model.addAttribute("successMessage", "Transfer successful");
	        } catch (AccountNotFoundException e) {
	            model.addAttribute("Account not found", e.getMessage());
	        }
	        return "dashboard";  
	    }
}


