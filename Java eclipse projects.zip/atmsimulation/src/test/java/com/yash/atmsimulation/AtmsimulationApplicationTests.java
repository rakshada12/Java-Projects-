package com.yash.atmsimulation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtmsimulationApplicationTests {

	@Test
	void contextLoads() {
	}

}
