package com.yash.HibernatewithDemo;

public class AppTest {
	public static void main(String[] args) {
		{
		System.out.println("Hello World");
		}
		}
		

}
