package com.yash.hibernatecrud.model;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Training_Details") 
public class Training {
	@Id
	@Column(name="Training_Id") 
	private int id;
	@Column(name="Training_Name") 
	private String trainingName;
	@Column(name="Training_Description") 
	private String description;
	@Column(name="Training_createdDate") 
	private Date createdAt;
	@Column(name="Training_updatedDate") 
	private Date updatedAt;

	    public Training(int id, String trainingName, String description) {
	    	this.id = id;
	        this.trainingName = trainingName;
	        this.description = description;
	        this.createdAt = new Date();
	        this.updatedAt = new Date();
	    }
	 
	    

		public int getId() {
	        return id;
	    }
	 
	    public void setId(int id) {
	this.id = id;
	        this.updatedAt = new Date();
	    }
	 
	    public String getTrainingName() {
	        return trainingName;
	    }
	 
	    public void setTrainingName(String trainingName) {
	        this.trainingName = trainingName;
	        this.updatedAt = new Date();
	    }
	 
	    public String getDescription() {
	        return description;
	    }
	 
	    public void setDescription(String description) {
	        this.description = description;
	        this.updatedAt = new Date();
	    }
	 
	   
	 
	    
	 
	    public Date getCreatedAt() {
	        return createdAt;
	    }
	 
	    public Date getUpdatedAt() {
	        return updatedAt;
	    }
	    
	    public Training() {
			// TODO Auto-generated constructor stub
		}
	 
	    



		@Override
	    public String toString() {
	        return "Training [ID=" + id + ", Training Name=" + trainingName + ", Description=" + description +
	               ", Created At=" + createdAt +
	               ", Updated At=" + updatedAt + "]";
	    }

}