package com.yash.hibernatecrud.dao;

import java.util.List;

import com.yash.hibernatecrud.model.Training;

public interface TrainingDao {
	public int insert(Training training); 
    public void delete(int id); 
    public void delete(Training training); 
    public void update(Training training); 
    public Training getTraining(int id); 
    public List<Training> getAllTrainings(); 

}
