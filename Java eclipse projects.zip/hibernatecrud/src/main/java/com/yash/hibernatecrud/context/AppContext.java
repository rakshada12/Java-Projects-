package com.yash.hibernatecrud.context;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppContext {
	private static ApplicationContext context; 
	  
    public static ApplicationContext provideContext() 
    { 
        if(context==null) 
        { 
            context=new ClassPathXmlApplicationContext("config.xml"); 
        } 
        return context; 
    } 

}
