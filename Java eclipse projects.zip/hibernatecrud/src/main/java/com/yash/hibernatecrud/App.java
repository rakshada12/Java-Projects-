package com.yash.hibernatecrud;

import org.springframework.context.ApplicationContext;

import com.yash.hibernatecrud.context.AppContext;
import com.yash.hibernatecrud.dao.TrainingDao;
import com.yash.hibernatecrud.model.Training;

/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) {
    	ApplicationContext ctx= AppContext.provideContext(); 
        TrainingDao trainingDao=ctx.getBean("trainingDao",TrainingDao.class); 
     
        
		
  
        // insert 

			Training training = new Training(1,"Java","java trng for freshers");
			 trainingDao.insert(training); 
	
       
    }
}

