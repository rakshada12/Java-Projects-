package com.yash.hibernatecrud.daoImpl;

import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;

import com.yash.hibernatecrud.dao.TrainingDao;
import com.yash.hibernatecrud.model.Training;

import jakarta.transaction.Transactional;

public class TrainingDaoImpl implements TrainingDao {
	 private HibernateTemplate hTemplate; 
	  
	    public void sethTemplate(HibernateTemplate hTemplate) { 
	        this.hTemplate = hTemplate; 
	    } 
	  
	    @Override
	    @Transactional
	    public int insert(Training training) { 
	        return (int) hTemplate.save(training); 
	    } 
	  
	    @Override
	    @Transactional
	    public void delete(int id) { 
	    	Training training=hTemplate.get(Training.class,id); 
	        hTemplate.delete(training); 
	    } 
	  
	    @Override
	    @Transactional
	    public void delete(Training training) { 
	        hTemplate.delete(training); 
	    } 
	  
	    @Override
	    @Transactional
	    public void update(Training training) { 
	        hTemplate.update(training); 
	    } 
	  
	    @Override
	    public Training getTraining(int id) { 
	        return hTemplate.get(Training.class,id); 
	    } 
	  
	    @Override
	    public List<Training> getAllTrainings() { 
	        return hTemplate.loadAll(Training.class); 
	    } 

}
