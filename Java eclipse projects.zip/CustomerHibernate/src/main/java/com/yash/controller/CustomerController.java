package com.yash.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.yash.model.Customer;
import com.yash.service.CustomerServiceImpl;

import java.util.List;
 
@Controller
@RequestMapping("/customers")
public class CustomerController {
 
    @Autowired
    private CustomerServiceImpl customerService;
 
    
    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("customer", new Customer());
        return "register"; 
    }
    
 
  
    @PostMapping("/register")
    public String registerCustomer(@ModelAttribute("customer") Customer customer) {
        customerService.registerCustomer(customer);
        return "redirect:/customers/list"; 
    }
 
    
    @GetMapping("/list")
    public String listCustomers(Model model) {
        List<Customer> customers = customerService.listCustomers();
        model.addAttribute("customers", customers);
        return "customer-list";
    }
 
   
    @GetMapping("/update/{id}")
    public String showUpdateForm(@PathVariable("id") Long id, Model model) {
        
        Customer customer = customerService.getCustomerById(id);
        if (customer == null) {
            throw new RuntimeException("Customer not found");
        }
        model.addAttribute("customer", customer);
        return "update";
    }
 
  
    @PostMapping("/update/{id}")
    public String updateCustomer(@PathVariable("id") Long id,
                                 @RequestParam("contactNo") String contactNo,
                                 @RequestParam("password") String password) {
  
        customerService.updateCustomerContactNo(id, contactNo);
        customerService.updateCustomerPassword(id, password);
 
        return "redirect:/customers/list";
    }
}