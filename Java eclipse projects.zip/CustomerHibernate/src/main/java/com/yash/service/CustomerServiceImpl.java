package com.yash.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yash.model.Customer;
import com.yash.repository.CustomerRepository;

import java.util.List;
 
@Service
@Transactional
public class CustomerServiceImpl {
 
    @Autowired
    private CustomerRepository customerRepo;
 
  
    public Customer registerCustomer(Customer customer) {
        
        return customerRepo.save(customer);
    }
 
   
    public List<Customer> listCustomers() {
        
        return customerRepo.findAll();
    }
 
 
    public Customer getCustomerById(Long id) {
       
        if (customerRepo.findById(id).isPresent()) {
            return customerRepo.findById(id).get();
        }
        return null;
    }
 
   
    public Customer updateCustomer(Customer customer) {
        return customerRepo.save(customer);
    }
 
    public void updateCustomerPassword(Long id, String newPassword) {
      
        Customer customer = getCustomerById(id);
        if (customer != null) {
            
            customer.setCustomerPassword(newPassword);
            customerRepo.save(customer);
        }
    }
 
   
    public void updateCustomerContactNo(Long id, String newContactNo) {
       
        Customer customer = getCustomerById(id);
        if (customer != null) {
        
            customer.setCustomerContactNo(newContactNo);
            customerRepo.save(customer);
        }
    }
}