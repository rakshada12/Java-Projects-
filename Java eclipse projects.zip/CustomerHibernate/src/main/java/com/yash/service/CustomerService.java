package com.yash.service;

import java.util.List;

import com.yash.model.Customer;



public interface CustomerService {

	public List<Customer> listCustomers();

	public Customer registerCustomer(Customer customer);
	
	public Customer updateCustomer(Long id, String newContactNo, String newPassword);

	
	
}
