package Practice;
 public class Example1 {
    public static void main(String[] args) {
       int[] arr ={3,5,9,10,11,12};
       int k=2;
       int a =0;
       int index =0;
       int b=0;
       while(true){
           a++;
           if(index<arr.length && arr[index] == a){
               index++;
           } else {
               b++;
               if(b == k){
                   System.out.println(a);
                   break;
                   
               }
               
           }
       }
    }
}