package com.springmvc.orm.controller.dao;

import java.util.List;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.springmvc.orm.controller.entity.Employee;
import com.springmvc.orm.controller.rowmapper.RowMap;

@Repository
public class empDao {

		@Autowired
		private HibernateTemplate hibernateTemplate;
		
		@Transactional
		public int saveuser(Employee emp)
		{
			
			Integer num = (Integer) this.hibernateTemplate.save(emp);
			return num ; 
		}

		@Transactional
		public void deleteUser(int id)
		{
			Employee emp = this.hibernateTemplate.get(Employee.class, id);
			hibernateTemplate.delete(emp);
		}
		
		
		public List<Employee> retrive()
		{
			
			List<Employee> list = this.hibernateTemplate.loadAll(Employee.class);
			return list;
					
		}
}
