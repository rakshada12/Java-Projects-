package com.springmvc.orm.controller.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springmvc.orm.controller.dao.empDao;
import com.springmvc.orm.controller.entity.Employee;


@Service
public class userService {

	@Autowired
	private empDao empDao;
	
	public int createUser(Employee emp)
	{
		return this.empDao.saveuser(emp);
	}
	
	public void deleteUsers(int id)
	{
		this.empDao.deleteUser(id);
	}
	
	public List<Employee> retriveAll()
	{
		return  this.empDao.retrive();
	}
	
}
