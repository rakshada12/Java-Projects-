package com.yash.technology.hotel.booking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudSpringBoot4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
