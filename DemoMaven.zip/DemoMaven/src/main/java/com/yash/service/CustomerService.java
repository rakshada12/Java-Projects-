package com.yash.service;

import java.util.List;

import com.yash.model.Customer;



public interface CustomerService {

	public List<Customer> getCustomers();

	public void saveCustomer(Customer theCustomer);

	
	
}
