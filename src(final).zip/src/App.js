import {
  BrowserRouter,
  Routes,
  Route
} from "react-router-dom";
import Home from "./pages/home/Home";
import Hotel from "./pages/hotel/Hotel";
import List from "./pages/list/List";
import Mumbai from "./pages/mumbai/Mumbai";
import Bangalore from "./pages/bangalore/Bangalore";
import Delhi from "./pages/delhi/Delhi";
import UserLogin from "./pages/UserLogin/Login";
import Register from "./pages/register/Register";
import ManagerLogin from "./pages/managerLogin/Login";
import RegisterManager from "./pages/managerRegistration/ManagerRegistration";
import HotelRegistration from "./pages/hotelRegistration/HotelRegister"
import MumbaiBook1 from "./pages/mumbai/MumbaiBook1";
import AdminLogin from "./pages/adminDashboard/Login"
import AdminDashboard from "./pages/adminDashboard/AdminDashboard";
import EditUser from "./pages/adminDashboard/EditUser";
import EditManager from "./pages/adminDashboard/EditManager";
import PaymenGpay from "./pages/mumbai/paymenGpay";
import ManagerDashboard from "./pages/managerDashboard/ManagerDashboard"
function App() {
    return (
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/hotels" element={<List />} />
          <Route path="/hotels/:id" element={<Hotel />} />
          <Route path="/register" element={<Register />} />
          <Route path="/mumbai" element={<Mumbai />} />
          <Route path="/hotelRegister" element={<HotelRegistration />} />
          <Route path="/managerRegistration" element={<RegisterManager />} />
          <Route path="/bangalore" element={<Bangalore />} />
          <Route path="/userlogin" element={<UserLogin />} />
          <Route path="/managerLogin" element={<ManagerLogin />} />
          <Route path="/delhi" element={<Delhi />} />
          <Route path="/mumbaiBook1" element={<MumbaiBook1/>}/>
          <Route path="/adminDashboard" element={<AdminDashboard/>}/>
          <Route path="/adminLogin" element={<AdminLogin/>}/>
          <Route path="/editUser" element={<EditUser/>}/>
          <Route path="/editManager" element={<EditManager/>}/>
          <Route path="/paymengpay" element={<PaymenGpay/>}/>
          <Route path="/managerDashboard" element={<ManagerDashboard/>}/>
        </Routes>

      </BrowserRouter>
    );
}

export default App;