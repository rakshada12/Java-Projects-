import styled from "styled-components";
import { useState } from "react";
import { Link as L } from "react-router-dom";
import { SettingsSystemDaydreamOutlined } from "@material-ui/icons";
import React from 'react';
// import { useEffect } from "react";
// import UserService from '../../services/UserService';
import Navbar from "../../components/navbar/Navbar";
import MailList from "../../components/mailList/MailList";
import Footer from "../../components/footer/Footer";
import { setData,getData } from "../../SessionMaintain";
import { useNavigate } from "react-router-dom";
const Container = styled.div`
  width: 100vw;
  height: 100vh;
  background: linear-gradient(
      rgba(255, 255, 255, 0.5),
      rgba(255, 255, 255, 0.5)
    ),
    url("https://images.pexels.com/photos/6984650/pexels-photo-6984650.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940")
      center;
  background-size: cover;
  display: flex;
  align-items: center;
  background-image: url("https://www.vobss.com/wp-content/uploads/2022/07/aesthetic-beach-wallpaper-vobss.jpg");
  justify-content: center;
`;

const Wrapper = styled.div`
  width: 25%;
  padding: 20px;
  background-color: white;

`;

const Title = styled.h1`
  font-size: 24px;
  font-weight: 300;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
`;

const Input = styled.input`
  flex: 1;
  min-width: 40%;
  margin: 10px 0;
  padding: 10px;
`;

const Button = styled.button`
  width: 100%;
  border: none;
  padding: 15px 20px;
  background-color: #003580;
  color: white;
  cursor: pointer;
  margin-bottom: 10px;
`;

const Link = styled.a`
  margin: 5px 0px;
  font-size: 12px;
  text-decoration: underline;
  cursor: pointer;
`;

const Login = () => {
  const [password, setPassword] = useState("");
  const [registrationNumber, setRegistrationNumber] = useState("");
  const [message, setMessage] = useState('');
  const navigate = useNavigate();
  // useEffect(() => {
  //     fetch("http://localhost:8080/getByUserEmail")
  //         .then(res => res.json())
  //         .then((result) => {
  //             alert(result);

  //         })

  // }, [])
  const handleClick = (event) => {
    //alert("check");
    event.preventDefault()
    const client = {registrationNumber,password}
    console.log(client);
    fetch("http://localhost:8080/getByManagementEmail", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(client)

    })
      .then(res => res.text())
          .then((result) => {
              if(result==="You can login"){
                const data=registrationNumber;
                setData(data);
                navigate("/hotelRegister");
              }
              else{
                setData("null");
                alert(result);
              }
    });

  };
  return (
    <><Navbar/>
    <Container>
      <Wrapper>
        <Title>MANAGER LOG IN</Title>
        <Form>
          <Input placeholder="Hotel registrationNumber" id="registrationNumber" name="registrationNumber" required 
          value={registrationNumber}
              onChange={(event) => setRegistrationNumber(event.target.value)} />
          <Input id="password" value={password} onChange={(event) => {
              setPassword(event.target.value)}} 
              placeholder="password" />
          <Button onClick={handleClick} > LOGIN</Button>
          <L to="/managerRegistration"><Button>CREATE A NEW ACCOUNT</Button></L>
        </Form>
      </Wrapper>
    </Container>
    <MailList/>
    <Footer/>
    </>
  );
};

export default Login;