import React from 'react'
import {  Navigate, useNavigate } from 'react-router-dom';
// import { faPerson,faParachuteBox } from '@fortawesome/free-solid-svg-icons';
import NavbarDashboard from "../../components/navbar/NavbarDashBoard"
import { useState, useEffect } from "react";
import { getData,setData } from '../../SessionMaintain';
export default function ManagerDashboard() {
    const [hotel, setHotel] = useState([]);
    const [id,setId]=useState("");
    const navigate=useNavigate();
    
    useEffect(() => {
        const id=getData();
        fetch("http://localhost:8080/getByHotelId/"+id)
            .then(res => res.json())
            .then((result) => {
                setHotel(result);
            }
            )
    }, [])
    
    return (
        <>
            <NavbarDashboard />
            <section><br></br>
                <div><center><h1><span style={{ color: "#003580" }}>Hotel Details</span></h1></center></div><br></br>
                <div >
                    <div >
                        <div><table>
                            <thead>
                                <tr>
                                    <th scope="col">Address</th>
                                    <th scope="col">Available Ac Rooms</th>
                                    <th scope="col">Available Non Ac Rooms</th>
                                    <th scope="col">Charges</th>
                                    <th scope="col">Food Included</th>
                                    <th scope="col">Hotel Name</th>
                                    <th scope="col">Is_Bar</th>
                                    <th scope="col">Total Bars</th>
                                </tr>
                            </thead>
                    
                            {hotel.map(hotels => (
                                <tbody key={hotels.registrationNumber}>
                                    <tr >
                                        <td>{hotels.address}</td>
                                        <td>{hotels.available_ac_rooms}</td>
                                        <td>{hotels.available_non_ac_rooms}</td>
                                        <td>{hotels.charges}</td>
                                        <td>{hotels.food_included}</td>
                                        <td>{hotels.hotel_name}</td>
                                        <td>{hotels.is_bar}</td>
                                        <td>{hotels.total_rooms}</td>
                                        {/* <td><button type="button" onMouseOver={() => setId(hotels.registrationNumber)} onClick={() => editHotel()}>Edit</button></td>
                                        <td><button type="button" onMouseOver={() => setId(hotels.registrationNumber)} onClick={() => deleteHotel()}>Delete</button></td>
                                   */} </tr> 
                                </tbody>
                            ))
                            }
                              </table>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

