
import React from "react";
import styled from "styled-components";
import { useState } from "react";
import { Navbar } from "react-bootstrap";
import Footer from "../../components/footer/Footer";
import MailList from "../../components/mailList/MailList";
import { useNavigate } from "react-router-dom";
//import "./hotelRegistration.css"

const Container = styled.div`
  width: 100vw;
  height: 100vh;
  background: linear-gradient(
      rgba(255, 255, 255, 0.5),
      rgba(255, 255, 255, 0.5)
    ),
    url("https://images.pexels.com/photos/6984661/pexels-photo-6984661.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940")
      center;
  background-size: cover;
  display: flex;
  align-items: center;
  background-image: url("https://www.vobss.com/wp-content/uploads/2022/07/aesthetic-beach-wallpaper-vobss.jpg");
  justify-content: center;
  
`;

const Wrapper = styled.div`
  width: 35%;
  padding: 20px;
  background-color: white;
  border-radius: 20px;
 
`;

const Title = styled.h1`
  font-size: 24px;
  font-weight: 300;
`;

const Form = styled.form`
  display: flex;
  flex-wrap: wrap;
`;

const Input = styled.input`
  flex: 1;
  min-width: 40%;
  margin: 20px 10px 0px 0px;
  padding: 10px;
`;

const Agreement = styled.span`
  font-size: 12px;
  margin: 20px 0px;
`;

const Button = styled.button`
  width: 100%;
  border: none;
  padding: 15px 20px;
  background-color: #003580;
  color: white;
  cursor: pointer;
  margin-top: 20px
  `;


const HotelRegister = () => {

    const [registrationNumber, setRegistrationNumber] = useState("");
    const [hotelName, setHotelName] = useState("");
    const [totalRooms, setTotalRooms] = useState("");
    const [availableAcRooms, setAvailableAcRooms] = useState("");
    const [availableNonAcRooms, setAvailableNonAcRooms] = useState("");
    const [address, setAddress] = useState("");
    const [charges, setCharges] = useState("");
    const [foodIncluded, setFoodIncluded] = useState("");
    const [isBar, setIsBar] = useState("");
    const [image, setImageUrl] = useState("");
    const [regNumError,setRegNumError] = useState("");
    const [totalRoomsError, setTotalRoomsError] = useState("");
let navigate=useNavigate();
 const handleClick2=()=>{
  navigate("/managerDashboard")
 }

    const handleClick = (event) => {

        alert("check");
        event.preventDefault()
        const hotel = {registrationNumber,hotelName,totalRooms,availableAcRooms,availableNonAcRooms,address,charges,foodIncluded,isBar,image}
        console.log(hotel);
        fetch("http://localhost:8080/saveHotelInformation", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(hotel)
        }).then(res => res.text())
        .then((result) => {
          alert(result);
        });
    
      }


      const submitHandler = (e) => {
        e.preventDefault()
        console.log("submitted");
      }


    const validRegistrationNumber=(e)=>{
        let regNumPattern = /^[A-Za-z0-9]*$/;
        
        if (regNumPattern.test(e.target.value)) {
            setRegistrationNumber(e.target.value);
            setRegNumError("")
        }
           else {
            console.log("please enter a valid Registration Number");
            setRegNumError("Please enter a valid Registration Number");
          }
    }

    const validTotalRooms = (e) => {
        let roomsPattern = /^\d+$/;

        if (e.target.value === "" || roomsPattern.test(e.target.value)) {
                setTotalRooms(e.target.value);
                setTotalRoomsError("")
        }
        else{
            console.log("please enter a no.");
            setTotalRoomsError("please enter a number");
        }

    }



    return (

    <div>
        <Navbar/>
        <Container>
        <Wrapper>
        <Title>Hotel Information Form</Title>
      <Form
       onSubmit={submitHandler}
    >
      <div>
          <Input type="text" maxLength={5} value={registrationNumber} onChange={validRegistrationNumber} placeholder="Enter hotel registration number" required/>
          
        </div>

        <div>
          <Input type="text" value={hotelName} onChange={(e)=>{
            setHotelName(e.target.value)
          }}
            placeholder="Enter hotel name" required/>
        </div>
        <div>
          <Input type="tel" value={totalRooms} onChange={validTotalRooms} placeholder="Enter Total Rooms" required/>
         
        </div>
       
        <div>
          <Input type="tel" value={availableAcRooms} onChange={(e)=>{
            setAvailableAcRooms(e.target.value)
          }} placeholder="Total Available Ac Rooms" required/>
        </div>
        <div>
          <Input type="tel" value={availableNonAcRooms} onChange={(e)=>{
            setAvailableNonAcRooms(e.target.value)
          }} placeholder="Total Available NonAc Rooms" required/>
        </div>
        <div>
          <Input type="text" value={address} onChange={(e)=>{
            setAddress(e.target.value)
          }} placeholder="Enter Your Address" required/>
        </div>
        <div>
          <Input type="tel" value={charges} onChange={(e)=>{
            setCharges(e.target.value)
          }} placeholder="Enter Charges" required/>
        </div>
        <div>
          <Input type="text" value={foodIncluded} onChange={(e) => {
              setFoodIncluded(e.target.value);
            }} placeholder="Enter Food Included or not(Yes/No)" required/>
        </div>
        <div>
          <Input type="text" value={isBar} onChange={(e) => {
              setIsBar(e.target.value);
            }} placeholder="Enter Bar Availabiliy(Yes/No)" required/>
           
        </div>
        <div>
            <Input type={"url"} value={image} onChange={(e)=>{
                setImageUrl(e.target.value)
            }} placeholder="Enter image url "/>
        </div>
        <div>
            
            <Button onClick={handleClick} >REGISTER</Button> 
            <div>
            <span style={{color:"red"}}>{regNumError}</span>
            <span style={{color:"red"}}>{totalRoomsError}</span>

            </div>
            <Button onClick={handleClick2} >Navigate to admin</Button>
        </div>
         </Form>
     
     </Wrapper>
    </Container>
        <MailList/>
        <Footer/>
    </div>
  );
}

export default HotelRegister;