
import styled from "styled-components";
import React, { Component, useEffect, useReducer, useState } from 'react';
import Navbar from "../../components/navbar/Navbar";
import Footer from "../../components/footer/Footer";
import MailList from "../../components/mailList/MailList";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCodeFork } from '@fortawesome/free-solid-svg-icons';
import { v4 as uuidv4 } from 'uuid';
import Icon from '@material-ui/core/Icon';
import { getData, setData } from "../../SessionMaintain";
import { makeStyles } from '@material-ui/core/styles';
import { useNavigate } from "react-router-dom";




const Container = styled.div`
  width: 100vw;
  height: 100vh;
  background: linear-gradient(
      rgba(255, 255, 255, 0.5),
      rgba(255, 255, 255, 0.5)
    ),
    url("https://images.pexels.com/photos/6984661/pexels-photo-6984661.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940")
      center;
  background-size: cover;
  display: flex;
  align-items: center;
  background-image: url("https://img.freepik.com/free-photo/maldives-island_74190-479.jpg?t=st=1657180375~exp=1657180975~hmac=44b40042230150b67abcae3f7e61a37e39d1b3f964915fd0bd0f53a94d9d2395&w=996");
  justify-content: center;
  
`;

const Wrapper = styled.div`
  width: 40%;
  padding: 20px;
  height:500px;
  justify-content: center;
  background-color: white;
  opacity:0.89;
  border-radius: 20px;
  overflow:auto;  
  
 
`;


const Wrapper1 = styled.div`

margin-right:35px;
  width: 40%;
  padding: 20px;
  height:500px;
  justify-content: center;
  background-color: white;
  opacity:0.89;
  border-radius: 20px;
 
  
 
`;

const Title = styled.h1`
  font-size: 35px;
  font-weight: 700;
  align-items:center;
  text-align:center;
  color: #003580;
  padding-top:10px;
  padding-bottom:11px;
  opacity:1;
  

`;

const Form = styled.form`
  display: flex;
  flex-wrap: wrap;
  opacity:1;
`;

const Input = styled.input`
  flex: 1;
  font-weight:400;
  font-size:20px;
  min-width: 40%;
  margin: 18px 10px 0px 0px;
  padding: 10px;
  opacity:1;
`;



const Button = styled.button`
  width: 40%;
  border: none;
  padding: 15px 20px;
  background-color: #003580;
  color: white;
  font-weight:bold;
  font-size:20px;
  cursor: pointer;
  margin-top:60px;
  margin-left:170px;
  opacity:1;
`;
const Button1 = styled.button`
  width: 21%;
  border: none;
  padding: 16px 20px;
  background-color: orange;
  color: black;
  font-weight:bold;
  font-size:12px;
  cursor: pointer;
  margin-right:20px;
  // align-items:center;
  opacity:1;
`;

const SiDesc = styled.div`
color:#003580;
align-items:center;
`;
const SiTitle = styled.h1`
   font-weight:bolder;
   color:#003580;
   padding-top:11px;
   padding-bottom:13px;
`;
const Desc = styled.span`
 color:black;
 font-weight:500;
 font-size:20px;
 float:left;
 justify-content:space-between;
 padding-bottom:11px;
 
`;

const Content = styled.div`
    display:flex;
`;


const Register = () => {
  const navigate = useNavigate();
  const [inputFields, setInputFields] = useState([
    { idi: uuidv4(), firstName: '', startDate: '', endDate: '', gender: "", lastName: '', email: '', contactNumber: '', age: '', hotelRegistrationNumber: 'LEE12' },
  ]);
  useEffect(() => {
    if (getData() === "null") {
      alert("You Need to login First");
      navigate("/userlogin");
    }
  });
  if (getData() !== "null") {
    const get = JSON.parse(getData());
    if (get.Role === 1) {
      const handleSubmit = (e) => {
        if (inputFields[0].firstName === "" || inputFields[0].lastName==="" || inputFields[0].age==="" ||inputFields[0].contactNumber==="" || inputFields[0].email==="" || inputFields[0].gender==="" ||inputFields[0].startDate==="") {
          alert("Fields should not be Empty");
        }
        else {
          e.preventDefault();
          console.log("InputFields", inputFields);
          let api = "http://localhost:8080/booking";
          fetch(api, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(inputFields)

          }).then(res => res.text())
            .then((result) => {
              const data={Role:get.Role,mail:get.mail,BookingId:result};
              setData(JSON.stringify(data));
              navigate("/paymenGpay")  
            });
        }
      };

      const handleChangeInput = (idi, event) => {
        const newInputFields = inputFields.map(i => {
          if (idi === i.idi) {
            i[event.target.name] = event.target.value
          }
          return i;
        })

        setInputFields(newInputFields);
      }

      const handleAddFields = () => {
        setInputFields([...inputFields, { startDate: '', endDate: '', firstName: '', lastName: '', email: '', contactNumber: '', gender: '', hotelRegistrationNumber: '' }])
      }

      const handleRemoveFields = id => {
        const values = [...inputFields];
        values.splice(values.findIndex(value => value.id === id), 1);
        setInputFields(values);
      }
      return (

        <>
          <Navbar />

          <Container>
            <Wrapper1>

              <SiDesc>
                <SiTitle><b>The Leela Mumbai </b>- Resort Style Business Hotel</SiTitle>

                <Desc>The Leela Mumbai is a 5 star luxury hotels in Mumbai near Mumbai international airport with a host of luxury amenities for leisure and business travelers.</Desc>
                <Desc>Near by Mumbai International Airport</Desc>
                <Desc>Free airport taxi</Desc><br />
                <Desc>
                  Sophisticated hotel with stylish restaurants & bars, plus an outdoor pool & a high-end spa.
                </Desc>
                <Desc><b>Features :</b></Desc>
                <Desc>
                  <b>5 star</b> | Top-rated | Great pool | Great location
                </Desc>
                <Desc>
                  <b>Price Includes :</b>
                  <li> <FontAwesomeIcon icon="faCodeFork" />Breakfast</li>
                  <li>Advance Purchase</li>
                  <Desc>
                  </Desc>
                </Desc>
              </SiDesc>
            </Wrapper1>


            <Wrapper>


              <Title>Guest Details</Title>

              <Form onSubmit={handleSubmit}>
                {inputFields.map(inputField => (
                  <div key={inputField.idi}>
                    <Input placeholder="Start Date (YYYY-MM-DD)" type={"date"}
                      name="startDate"
                      label="startDate"
                      variant="filled"
                      value={inputField.startDate}
                      onChange={event =>
                        handleChangeInput(inputField.idi, event)
                      }


                      required />
                    <Input placeholder="End Date (YYYY-MM-DD)" type={"date"}
                      name="endDate"
                      label="endDate"
                      variant="filled"
                      value={inputField.endDate}
                      onChange={event =>
                        handleChangeInput(inputField.idi, event)
                      }
                      recquired />
                    <Input placeholder="Enter First name" type={"text"}
                      name="firstName"
                      label="First Name"
                      variant="filled"
                      value={inputField.firstName}
                      onChange={event => handleChangeInput(inputField.idi, event)}
                      required />

                    <Input placeholder="Enter Last name" type={"text"}
                      name="lastName"
                      label="Last Name"
                      variant="filled"
                      value={inputField.lastName}
                      onChange={event => handleChangeInput(inputField.idi, event)}
                      required />

                    <Input placeholder="Enter Email id" type={"email"}
                      name="email"
                      label="email"
                      variant="filled"
                      value={inputField.email}
                      onChange={event => handleChangeInput(inputField.idi, event)}
                      required />
                    <Input placeholder="Enter Mobile number" type={"tel"}
                      name="contactNumber"
                      label="mobileNumber"
                      variant="filled"
                      value={inputField.mobileNumber}
                      onChange={event => handleChangeInput(inputField.idi, event)}
                      required />
                    <Input placeholder="Enter Age" type={"text"}
                      name="age"
                      label="age"
                      variant="filled"
                      value={inputField.age}
                      onChange={event => handleChangeInput(inputField.idi, event)}
                      required />
                    <Input placeholder="Enter Gender" type={"text"}
                      name="gender"
                      label="gender"
                      variant="filled"
                      value={inputField.gender}
                      onChange={event => handleChangeInput(inputField.idi, event)}
                      required />
                    <Button1 disabled={inputFields.length === 1} onClick={() => handleRemoveFields(inputField.id)}>RemoveGuest</Button1>
                    <Button1 onClick={handleAddFields}>AddGuest</Button1>


                  </div>

                ))}

              </Form>
              <Button variant="contained"
                color="primary"
                type="submit"
                endIcon={<Icon>send</Icon>}
                onClick={handleSubmit}>Pay Now</Button>

            </Wrapper>
          </Container>
          <MailList />
          <Footer /></>
      )
    }
  }
}
export default Register;

