import styled from "styled-components";

import React, { Component, useEffect, useReducer, useState } from 'react';

import Navbar from "../../components/navbar/Navbar";
import Footer from "../../components/footer/Footer";
import MailList from "../../components/mailList/MailList";
import { useNavigate } from "react-router-dom";
//import "./register.css";



const Container = styled.div`
  width: 100vw;
  height: 100vh;
  background: linear-gradient(
      rgba(255, 255, 255, 0.5),
      rgba(255, 255, 255, 0.5)
    ),
    url("https://images.pexels.com/photos/6984661/pexels-photo-6984661.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940")
      center;
  background-size: cover;
  display: flex;
  align-items: center;
  background-image: url("https://www.vobss.com/wp-content/uploads/2022/07/aesthetic-beach-wallpaper-vobss.jpg");
  justify-content: center;
  
`;

const Wrapper = styled.div`
  width: 40%;
  padding: 20px;
  background-color: white;
  border-radius: 20px;
 
  
 
`;

const Title = styled.h1`
  font-size: 24px;
  font-weight: 300;
`;

const Form = styled.form`
  display: flex;
  flex-wrap: wrap;
`;

const Input = styled.input`
  flex: 1;
  min-width: 40%;
  margin: 20px 10px 0px 0px;
  padding: 10px;
`;

const Agreement = styled.span`
  font-size: 12px;
  margin: 20px 0px;
`;

const Button = styled.button`
  width: 99%;
  border: none;
  padding: 15px 20px;
  background-color: #003580;
  color: white;
  cursor: pointer;
`;

const Register = () => {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [mobileNumber, setMobileNumber] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [profession, setProfession] = useState("");
  const [address, setAddress] = useState("");
  const [otp, setOtp] = useState("");
  let navigate=useNavigate();

  const handleClick1 = (event) => {
    if(name===""||email===""||password===""||mobileNumber===""||profession===""||email===""){
      alert("fields are empty")
      }
      else{
    event.preventDefault()
    const client = { email }
    console.log(client);
    let api="http://localhost:8080/getOtp/"+ email;
    fetch(api, {
      method: "GET",
      //headers: { "Content-Type": "application/json" },
      // body: JSON.stringify(client)
    }).then(res => res.text())
      .then((result) => {
         alert(result);
      });
    };
  }
    const handleClick2 = (event) => {
      if(name===""||email===""||password===""||mobileNumber===""||profession===""||email===""){
      alert("fields are empty")
      }
      else{
      event.preventDefault()
      const client = {otp}
      console.log(client);
      let api="http://localhost:8080/validateOtp/"+otp;
      fetch(api, {
        method: "GET",
        // headers: { "Content-Type": "application/json" },
        // body: JSON.stringify(client)
      }).then(res => res.text())
        .then((result) => {
          if(result==="you can login"){
            const client = { name, age, mobileNumber, email, password, profession, address }
            console.log(client);
            fetch("http://localhost:8080/register", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(client)
            }).then(res => res.text())
              .then((result) => {
                alert(result);
                navigate("/userLogin");
              });
          }
          else{
            alert(result);
          }
        });
    };
  }

  const [nameError, setNameError] = useState("");


  
const validName = (e) => {

  let namePattern = /^[a-zA-Z]+$/;
  if (e.target.value === "" || namePattern.test(e.target.value)) {
     setName(e.target.value);
     setNameError("")
  } else {
    console.log("please enter a valid name");
    setNameError("Please enter a valid name");
  }

};

const [ageError, setAgeError] = useState("");
const validAge = (e) => {
  let agePattern = /^\d+$/;

  if(e.target.value==="" || agePattern.test(e.target.value)){
    setAge(e.target.value)
    setAgeError("")
  }
  else{
    setAgeError("Please enter value age in number")
  }
}

const [mobileNumberError, setMobileNumberError] = useState("");

const validMobileNumber = (e) => {
    

  let contactPattern = /^\d+$/;

  if (e.target.value === "" || contactPattern.test(e.target.value)) {
    setMobileNumber(e.target.value);
    setMobileNumberError("")
  }
  else{
  console.log("please enter a valid no.");
  setMobileNumberError("please enter a valid number");
  }

};

// const [emailError, setEmailError] = useState("");
// const validEmail = (e) => {
//   let emailPattern = /^[a-zA-Z0-9]+@+[a-zA-Z0-9]+.+[A-z]/;
//   if (e.target.value === "" || !emailPattern.test(e.target.value)) {
//      setEmail(e.target.value);
//      setEmailError("");
//   } else {
//     console.log("please enter a valid Email");
//     setEmailError("Please enter a valid Email");
//   }
// };

const [professionError, setProfessionError] = useState("");
const validProfession = (e) => {

  let professionPattern = /^[a-zA-Z]+$/;
  if (e.target.value === "" || professionPattern.test(e.target.value)) {
     setProfession(e.target.value);
     setProfessionError("")
  } else {
    console.log("please enter a valid Profession");
    setNameError("Please enter a valid Profession");
  }

};

const [passwordError, setPasswordError] = useState("");
const validPassword = (e) => {
   
  let passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,20}$/;

  setPassword(e.target.value);
  if (!passwordPattern.test(e.target.value)) {
    console.log("please enter strong password");
    setPasswordError("Please enter strong password(A-Z, a-z,@#!$.,1234..)");
  } else {
    console.log("success");
    setPasswordError("");
  }

};

const [addressError, setAddressError] = useState("");

const validAddress = (e) => {
  let addressPattern = /^[A-Za-z0-9]*$/;
  if (e.target.value === "" || addressPattern.test(e.target.value)) {
     setAddress(e.target.value);
     setAddressError("")
  } else {
    console.log("please enter a valid Address");
    setAddressError("Please enter a valid Address");
  }
};


    
  return (
    <><Navbar /><Container>
      <Wrapper>

        <Title>CREATE AN ACCOUNT</Title>
        <Form> 


          <Input placeholder="full name" type={"text"} id="name" name="name"
            value={name} onChange={(validName)
            }
             required />

            


          <Input placeholder="age" id="age" name="age" type={"tek"}
            value={age}  maxLength={2} onChange={validAge}
            required />
            
          


          <Input placeholder="contact no." id="mobileNumber" name="mobileNumber"
            value={mobileNumber} onChange={validMobileNumber
            }
            type={"tel"}  maxLength={10} required />
          

          <Input placeholder="email id" type={"email"} id="email" name="email"
            value={email} 
            onChange={(e) => {setEmail(e.target.value)}}
            required />
          {/* <span style={{ color: "red", fontSize:"13px" }}>{emailError}</span> */}


          <Input placeholder="profession" type={"text"} id="profession" name="profession"
            value={profession} onChange={validProfession}
            required />
           


          <Input placeholder="password" type={"password"} id="password" name="password"
            value={password} onChange={validPassword}
             required />
             

          <Input placeholder="Address" id="address" name="address"
            value={address} onChange={validAddress}
            type={"text"} required />



          <Input placeholder="otp" id="otp" name="otp"
            value={otp} onChange={(event) => {
              setOtp(event.target.value)
            }} type={"text"} required />
          <Agreement>
            By creating an account, I consent to the processing of my personal
            data in accordance with the <b>PRIVACY POLICY</b>
            <div>
           <span style={{ color: "red", fontSize:"13px" }}>{nameError}</span>
            <span style={{color:"red"}}>{ageError}</span>
            <span style={{color:"red"}}>{mobileNumberError}</span>
            <span style={{ color: "red", fontSize:"13px" }}>{professionError}</span>
            <span style={{ color: "red", fontSize:"13px" }}>{passwordError}</span>
            <span style={{ color: "red", fontSize:"13px" }}>{addressError}</span>

            </div>
          </Agreement>
          <Button onClick={handleClick1}>Get OTP</Button>
          <Button onClick={handleClick2}>Validate and Create User</Button>
        </Form>
      </Wrapper>
    </Container>
      <MailList />
      <Footer /></>
  );
};

export default Register;
