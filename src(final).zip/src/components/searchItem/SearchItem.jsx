import "./searchItem.css";

const SearchItem = () => {
  return (
    <>
    <div className="searchItem">
      <img
        src="https://lh3.googleusercontent.com/p/AF1QipOLNIaobilE98k-2VCKwqbPAAVSGtnHgpJFKlBY=w592-h404-n-k-rw-no-v1"
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">The Leela Mumbai - Resort Style Business Hotel</h1>
        <span className="siDistance">Near by Mumbai International Airport</span>
        <span className="siTaxiOp">Free airport taxi</span>
        <span className="siSubtitle">
        Sophisticated hotel with stylish restaurants & bars, plus an outdoor pool & a high-end spa.
        </span>
        <span className="siFeatures">
          <b>5 star</b> | Top-rated | Great pool | Great location
        </span>
        <span className="siCancelOp">Free cancellation </span>
        <span className="siCancelOpSubtitle">
          You can cancel later, so lock in this great price today!
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Outstanding</span>
          <button>9.5</button>
        </div>
        <div className="siDetailTexts">
          <span className="siPrice">Starts from Rs. 8000 per night </span>
          <span className="siTaxOp">Includes taxes and fees</span>
          <button className="siCheckButton">See availability</button>
        </div>
      </div>
    </div>

{/* second search item */}

    <div className="searchItem">
      <img
        src="https://lh3.googleusercontent.com/p/AF1QipPgIWRdCmLgUqrjt-88_Ec2VXXkJQmt_Xoa5iSf=w592-h404-n-k-rw-no-v1"
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">ITC Maratha, a Luxury Collection Hotel</h1>
        <span className="siDistance">Ashok Nagar, Andheri East</span>
        <span className="siTaxiOp">Free airport taxi</span>
        <span className="siSubtitle">
        Grand hotel offering refined quarters, plus upscale dining, an outdoor pool & a spa.
        </span>
        <span className="siFeatures">
          <b>5 star</b> | Breakfast | Free wifi | Outdoor pool
        </span>
        <span className="siCancelOp">Free cancellation </span>
        <span className="siCancelOpSubtitle">
          You can cancel later, so lock in this great price today!
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Outstanding</span>
          <button>9.5</button>
        </div>
        <div className="siDetailTexts">
          <span className="siPrice">Starts from Rs. 8387 per night </span>
          <span className="siTaxOp">Includes taxes and fees</span>
          <button className="siCheckButton">See availability</button>
        </div>
      </div>
    </div>
    <div className="searchItem">
      <img
        src="https://lh3.googleusercontent.com/p/AF1QipM3DLo6KsKnOylrOdawe9K23POEV9akSbRB7Zik=w592-h404-n-k-rw-no-v1"
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">Holiday Inn Bengaluru Racecourse</h1>
        <span className="siDistance">Gandhi Nagar Bengaluru</span>
        <span className="siTaxiOp">Free airport taxi</span>
        <span className="siSubtitle">
        Cosy rooms in a functional lodging offering complimentary breakfast & Wi-Fi, plus a gym & a pool.
        </span>
        <span className="siFeatures">
          <b>5 star</b> | Breakfast | Free wifi | Outdoor pool
        </span>
        <span className="siCancelOp">Free cancellation </span>
        <span className="siCancelOpSubtitle">
          You can cancel later, so lock in this great price today!
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Outstanding</span>
          <button>9.5</button>
        </div>
        <div className="siDetailTexts">
          <span className="siPrice">Starts from Rs. 5348 per night </span>
          <span className="siTaxOp">Includes taxes and fees</span>
          <button className="siCheckButton">See availability</button>
        </div>
      </div>
    </div>


    <div className="searchItem">
      <img
        src="https://lh3.googleusercontent.com/p/AF1QipOfFsz8Lg-cy2jpKPv5fK-z5jCcDHnprmkZoBhR=w592-h404-n-k-rw-no-v1"
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">Lemon Tree Premier</h1>
        <span className="siDistance">Hermit Colony, Sivanchetti Gardens, Halasuru, Bangaluru</span>
        <span className="siTaxiOp">Free airport taxi</span>
        <span className="siSubtitle">
        Informal hotel offering warm rooms & suites, plus dining, a spa & a rooftop outdoor pool.
        </span>
        <span className="siFeatures">
          <b>4 star</b> |  Free Breakfast | Free wifi | Indoor pool
        </span>
        <span className="siCancelOp">Free cancellation </span>
        <span className="siCancelOpSubtitle">
          You can cancel later, so lock in this great price today!
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Excellent</span>
          <button>8.5</button>
        </div>
        <div className="siDetailTexts">
          <span className="siPrice">Starts from Rs. 4567 per night </span>
          <span className="siTaxOp">Includes taxes and fees</span>
          <button className="siCheckButton">See availability</button>
        </div>
      </div>
    </div>



    <div className="searchItem">
      <img
        src="https://lh3.googleusercontent.com/p/AF1QipPMbSTrbNYLcsF572pr8E8SViXeHdyibA3WrAur=w592-h404-n-k-rw-no-v1"
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">Ashiana Clarks Inn, Shimla</h1>
        <span className="siDistance">Near Secretriate, Chota Shimla, Himachal Pradesh</span>
        <span className="siTaxiOp">Pickup and Drop</span>
        <span className="siSubtitle">
        Casual quarters, some with mountain views, in a relaxed hotel offering a rooftop restaurant & a bar.
        </span>
        <span className="siFeatures">
          <b>3 star</b> |  Free Breakfast | Free parking | Bar
        </span>
        <span className="siCancelOp">Free cancellation </span>
        <span className="siCancelOpSubtitle">
          You can cancel later, so lock in this great price today!
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Excellent</span>
          <button>8.5</button>
        </div>
        <div className="siDetailTexts">
          <span className="siPrice">Starts from Rs. 4686 per night </span>
          <span className="siTaxOp">Includes taxes and fees</span>
          <button className="siCheckButton">See availability</button>
        </div>
      </div>
    </div>


    <div className="searchItem">
      <img
        src="https://lh3.googleusercontent.com/proxy/hqk0B27HtLgxknBX4LtU8ywd-X3UOK8OTjwfnkJgauN3zyPXqfDIvAolobm4f4HJJJQH8nzFHsNzIKnms999nCu3WuZvpDteQac9_gRoo0xg93iBr4aMjplWeI2s3yyLzhAE78b81u364afY5oR7rqOQ-Axs7KQ=w592-h404-n-k-rw-no-v1"
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">Novotel New Delhi Aerocity </h1>
        <span className="siDistance"> Igi Airport, New Delhi</span>
        <span className="siTaxiOp">Pickup and Drop</span>
        <span className="siSubtitle">
        Polished modern lodging offering a restaurant & a bar, plus a gym & a heated outdoor pool.
        </span>
        <span className="siFeatures">
          <b>5 star</b> | Breakfast | Free wifi | Outdoor Pool | Hot Tub
        </span>
        <span className="siCancelOp">Free cancellation </span>
        <span className="siCancelOpSubtitle">
          You can cancel later, so lock in this great price today!
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Excellent</span>
          <button>8.5</button>
        </div>
        <div className="siDetailTexts">
          <span className="siPrice">Starts from Rs. 7560 per night </span>
          <span className="siTaxOp">Includes taxes and fees</span>
          <button className="siCheckButton">See availability</button>
        </div>
      </div>
    </div>



    <div className="searchItem">
      <img
        src="https://lh3.googleusercontent.com/proxy/_uHC6Om0qzBuEV0UWxANWPLCEnVf2v-vDA54xU1QpcXwZC5S_EhN1qrOTWuNQepAQ0foh-eH4RkEgg3ppo8FVdsrIGrTKUICYxxUhXw_-LrM8jgyeUCGDLZvnAZHeStKReaqmdgEJXRAUa8z7ICiaol35-bhosk=w592-h404-n-k-rw-no-v1"
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">DoubleTree by Hilton Hotel Goa- Arpora - Baga </h1>
        <span className="siDistance"> 11 min drive to Baga Beach, Goa</span>
        <span className="siTaxiOp">Pickup and Drop</span>
        <span className="siSubtitle">
        Airy rooms, some with balconies, in a casual hotel offering 2 restaurants, an outdoor pool & a spa.
        </span>
        <span className="siFeatures">
          <b>5 star</b> | Breakfast | Free parking | Outdoor Pool
        </span>
        <span className="siCancelOp">Free cancellation </span>
        <span className="siCancelOpSubtitle">
          You can cancel later, so lock in this great price today!
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Excellent</span>
          <button>8.5</button>
        </div>
        <div className="siDetailTexts">
          <span className="siPrice">Starts from Rs. 4703 per night </span>
          <span className="siTaxOp">Includes taxes and fees</span>
          <button className="siCheckButton">See availability</button>
        </div>
      </div>
    </div>


    <div className="searchItem">
      <img
        src="https://lh3.googleusercontent.com/p/AF1QipOB7L2giqJIL34x_pa3BG7zfKIKzaHVBZTd7YJc=w592-h404-n-k-rw-no-v1"
        alt=""
        className="siImg"
      />
      <div className="siDesc">
        <h1 className="siTitle">Radisson Blu Marina Hotel Connaught Place </h1>
        <span className="siDistance">Connaught Circus, New Delhi</span>
        <span className="siTaxiOp">Pickup and Drop</span>
        <span className="siSubtitle">
        Understated quarters with free WiFi, plus 2 restaurants, a spa & a fitness centre.
        </span>
        <span className="siFeatures">
          <b>4 star</b> | Breakfast | Spa | Outdoor Pool | Fitness Centre
        </span>
        <span className="siCancelOp">Free cancellation </span>
        <span className="siCancelOpSubtitle">
          You can cancel later, so lock in this great price today!
        </span>
      </div>
      <div className="siDetails">
        <div className="siRating">
          <span>Excellent</span>
          <button>8.5</button>
        </div>
        <div className="siDetailTexts">
          <span className="siPrice">Starts from Rs. 3815 per night </span>
          <span className="siTaxOp">Includes taxes and fees</span>
          <button className="siCheckButton">See availability</button>
        </div>
      </div>
    </div>
    </>
  );
};

export default SearchItem;
