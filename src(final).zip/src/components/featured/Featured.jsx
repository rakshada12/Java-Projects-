import { Link } from "react-router-dom";
import "./featured.css";
import Mumbai1 from "../../images/Mumbai1.jpg"
import Bangalore1 from "../../images/Bangalore1.jpg"
import Delhi1 from "../../images/Delhi1.jpg"
const Featured = () => {
  return (
    <div className="featured">
      <div className="featuredItem">
        <Link to="/mumbai"><img
          // src="https://www.timeoutdubai.com/public/images/2019/07/08/Mumbai.jpg"
          src = {Mumbai1}
          alt=""
          className="featuredImg"
        /></Link>
        <div className="featuredTitles">
          <h1>Mumbai</h1>
          <h2>2 Hotels Available</h2>
        </div>
      </div>
      
      <div className="featuredItem">
      <Link to="/bangalore"> <img
          //src="	https://www.visittnt.com/blog/wp-content/uploads/2018/10/Bangalore-Palace-Bangalore.jpg"
          src= {Bangalore1}
          alt=""
          className="featuredImg"
        /></Link>
        <div className="featuredTitles">
          <h1>Bangalore</h1>
          <h2>2 Hotels Available</h2>
        </div>
      </div>
      <div className="featuredItem">
      <Link to="/delhi"> <img
          //src="	https://www.mistay.in/travel-blog/content/images/2020/07/travel-4813658_1920.jpg"
          src= {Delhi1}
          alt=""
          className="featuredImg"
        />
        </Link>
        <div className="featuredTitles">
          <h1>Delhi</h1>
          <h2>2 Hotels Available </h2>
        </div>
      </div>
    </div>
  );
};

export default Featured;
